import Link from "next/link";
import { requireStore, hasPermission } from "@/lib/auth";
import { createServerSupabase } from "@/lib/supabase/server";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ProductRowActions } from "@/components/products/product-row-actions";

const PAGE_SIZE = 20;

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: { q?: string; status?: string; page?: string };
}) {
  const store = await requireStore();
  const canCreate = await hasPermission(store.id, "products.create");
  const canDelete = await hasPermission(store.id, "products.delete");

  const supabase = createServerSupabase();
  const page = Math.max(1, Number(searchParams.page ?? 1));
  const from = (page - 1) * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;

  let query = supabase
    .from("products")
    .select("id, name, sku, price, stock, status, low_stock_threshold", { count: "exact" })
    .eq("store_id", store.id)
    .order("created_at", { ascending: false })
    .range(from, to);

  if (searchParams.q) query = query.ilike("name", `%${searchParams.q}%`);
  if (searchParams.status) query = query.eq("status", searchParams.status);

  const { data: products, count } = await query;
  const totalPages = Math.max(1, Math.ceil((count ?? 0) / PAGE_SIZE));

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-slate-900">Products</h1>
        {canCreate && (
          <Link href="/dashboard/products/new">
            <Button>+ New product</Button>
          </Link>
        )}
      </div>

      <form className="mb-4 flex gap-3" method="get">
        <Input name="q" placeholder="Search by name…" defaultValue={searchParams.q} className="max-w-xs" />
        <select
          name="status"
          defaultValue={searchParams.status ?? ""}
          className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
        >
          <option value="">All statuses</option>
          <option value="draft">Draft</option>
          <option value="active">Active</option>
          <option value="archived">Archived</option>
        </select>
        <Button type="submit" variant="secondary">Filter</Button>
      </form>

      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-slate-500">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">SKU</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">Stock</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {(products ?? []).map((p) => (
              <tr key={p.id} className="border-t border-slate-100">
                <td className="px-4 py-3 font-medium text-slate-900">{p.name}</td>
                <td className="px-4 py-3 text-slate-500">{p.sku ?? "—"}</td>
                <td className="px-4 py-3">{Number(p.price).toFixed(2)} {store.currency}</td>
                <td className="px-4 py-3">
                  <span className={p.stock <= p.low_stock_threshold ? "font-semibold text-amber-600" : ""}>
                    {p.stock}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className="rounded-full bg-slate-100 px-2 py-1 text-xs capitalize">{p.status}</span>
                </td>
                <td className="px-4 py-3 text-right">
                  <ProductRowActions productId={p.id} canDelete={canDelete} />
                </td>
              </tr>
            ))}
            {(!products || products.length === 0) && (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-slate-400">
                  No products yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="mt-4 flex justify-center gap-2">
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
            <Link
              key={p}
              href={`/dashboard/products?page=${p}${searchParams.q ? `&q=${searchParams.q}` : ""}`}
              className={`rounded px-3 py-1 text-sm ${p === page ? "bg-brand-600 text-white" : "bg-white text-slate-600 border"}`}
            >
              {p}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
