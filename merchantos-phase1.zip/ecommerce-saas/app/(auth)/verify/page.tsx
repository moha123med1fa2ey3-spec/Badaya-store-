import Link from "next/link";

export default function VerifyPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
        <h1 className="mb-2 text-xl font-semibold text-slate-900">Email verified</h1>
        <p className="mb-6 text-sm text-slate-500">Your email is confirmed. You can log in now.</p>
        <Link href="/login" className="text-brand-600 hover:underline">Go to login</Link>
      </div>
    </div>
  );
}
