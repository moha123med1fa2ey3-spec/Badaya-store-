import { requireStore, requirePermission } from "@/lib/auth";
import { Card } from "@/components/ui/card";

export default async function SettingsPage() {
  const store = await requireStore();
  await requirePermission(store.id, "settings.manage");

  return (
    <div>
      <h1 className="mb-6 text-2xl font-semibold text-slate-900">Settings</h1>
      <Card>
        <p className="text-sm text-slate-600">
          Store profile, domains, payment providers, and shipping settings will be built here in Phase 2,
          wired to <code>store_settings</code> and <code>store_domains</code>.
        </p>
        <dl className="mt-4 grid grid-cols-2 gap-2 text-sm">
          <dt className="text-slate-500">Store name</dt><dd>{store.name}</dd>
          <dt className="text-slate-500">Currency</dt><dd>{store.currency}</dd>
        </dl>
      </Card>
    </div>
  );
}
