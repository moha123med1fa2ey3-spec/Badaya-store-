import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MerchantOS — Multi-Tenant E-Commerce Platform",
  description: "Manage your store: products, orders, inventory, and customers.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" dir="ltr">
      <body className="min-h-screen font-sans antialiased">{children}</body>
    </html>
  );
}
