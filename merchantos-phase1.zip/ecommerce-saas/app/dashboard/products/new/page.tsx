import { requireStore, requirePermission } from "@/lib/auth";
import { createServerSupabase } from "@/lib/supabase/server";
import { ProductForm } from "@/components/products/product-form";
import { createProduct } from "@/lib/actions/products";

export default async function NewProductPage({ searchParams }: { searchParams: { error?: string } }) {
  const store = await requireStore();
  await requirePermission(store.id, "products.create");

  const supabase = createServerSupabase();
  const { data: categories } = await supabase.from("categories").select("id, name").eq("store_id", store.id).order("name");

  return (
    <div>
      <h1 className="mb-6 text-2xl font-semibold text-slate-900">New product</h1>
      <ProductForm action={createProduct} categories={categories ?? []} error={searchParams.error} submitLabel="Create product" />
    </div>
  );
}
