import { redirect } from "next/navigation";
import { getCurrentUser, getCurrentStore } from "@/lib/auth";

export default async function Home() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const store = await getCurrentStore();
  redirect(store ? "/dashboard" : "/onboarding/create-store");
}
