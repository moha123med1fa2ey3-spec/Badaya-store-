import { requireStore } from "@/lib/auth";
import { createServerSupabase } from "@/lib/supabase/server";
import { Card } from "@/components/ui/card";

async function getStats(storeId: string) {
  const supabase = createServerSupabase();

  const [{ count: productCount }, { count: activeCount }, { count: lowStockCount }, { count: categoryCount }] =
    await Promise.all([
      supabase.from("products").select("id", { count: "exact", head: true }).eq("store_id", storeId),
      supabase.from("products").select("id", { count: "exact", head: true }).eq("store_id", storeId).eq("status", "active"),
      supabase
        .from("products")
        .select("id", { count: "exact", head: true })
        .eq("store_id", storeId)
        .lte("stock", 5),
      supabase.from("categories").select("id", { count: "exact", head: true }).eq("store_id", storeId),
    ]);

  return {
    productCount: productCount ?? 0,
    activeCount: activeCount ?? 0,
    lowStockCount: lowStockCount ?? 0,
    categoryCount: categoryCount ?? 0,
  };
}

export default async function DashboardOverviewPage() {
  const store = await requireStore();
  const stats = await getStats(store.id);

  const cards = [
    { label: "Total products", value: stats.productCount },
    { label: "Active products", value: stats.activeCount },
    { label: "Low stock (≤5)", value: stats.lowStockCount },
    { label: "Categories", value: stats.categoryCount },
  ];

  return (
    <div>
      <h1 className="mb-6 text-2xl font-semibold text-slate-900">Overview</h1>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {cards.map((c) => (
          <Card key={c.label}>
            <p className="text-sm text-slate-500">{c.label}</p>
            <p className="mt-1 text-3xl font-semibold text-slate-900">{c.value}</p>
          </Card>
        ))}
      </div>
      <Card className="mt-6">
        <p className="text-sm text-slate-600">
          Revenue, orders, and customer stats will appear here once the Orders and Payments modules are built (Phase 2).
        </p>
      </Card>
    </div>
  );
}
